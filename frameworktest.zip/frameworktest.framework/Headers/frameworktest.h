//
//  frameworktest.h
//  frameworktest
//
//  Created by Jordan Campbell on 8/01/18.
//  Copyright © 2018 Atlas Innovation. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for frameworktest.
FOUNDATION_EXPORT double frameworktestVersionNumber;

//! Project version string for frameworktest.
FOUNDATION_EXPORT const unsigned char frameworktestVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <frameworktest/PublicHeader.h>


